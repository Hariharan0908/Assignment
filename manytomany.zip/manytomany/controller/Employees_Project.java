package manytomany.controller;

import java.util.ArrayList;
import java.util.List;

import manytomany.dao.Employeesdao;
import manytomany.dao.Projectdao;
import manytomany.dto.Employees;
import manytomany.dto.Project;

public class Employees_Project 
{
	public static void main(String[] args) 
{
//		Project proj1 = new Project();
//		proj1.setId(1);
//		proj1.setClient("UPS");
//		proj1.setWbs_code("	US.720050.001.01");
//		proj1.setManager_name("Sambit Das");
//		proj1.setTech("SharePoint");
//		
//		Project proj2 = new Project();
//		proj2.setId(2);
//		proj2.setClient("NIEN");
//		proj2.setWbs_code("	NE.202001.330.01");
//		proj2.setManager_name("Raghevandra");
//		proj2.setTech("M365");
//		
//		Project proj3 = new Project();
//		proj3.setId(3);
//		proj3.setClient("All State - Canada");
//		proj3.setWbs_code("	Al-98338.009.01");
//		proj3.setManager_name("Rajaram");
//		proj3.setTech("Java");
//		
//		Employees emp1 = new Employees();
//		emp1.setId(98088);
//		emp1.setName("Hariharan");
//		emp1.setRole("Developer");
//		emp1.setGCM(2);
//		
//		List<Project> projofhari = new ArrayList<Project>();
//		projofhari.add(proj3);
//		projofhari.add(proj1);
//		emp1.setProj(projofhari);
//		
//		Employees emp2 = new Employees();
//		emp2.setId(780876);
//		emp2.setName("Vimalraj");
//		emp2.setRole("M365 Administrator");
//		emp2.setGCM(4);
//		emp2.setProj(projofhari);
//		
//		Employees emp3 = new Employees();
//		emp3.setId(837198);
//		emp3.setName("Harinath");
//		emp3.setRole("Developer");
//		emp3.setGCM(2);
//		
//		List<Project> projofharinath = new ArrayList<Project>();
//		projofharinath.add(proj3);
//		projofharinath.add(proj1);
//		projofharinath.add(proj2);
//		emp3.setProj(projofharinath);
		
		Projectdao projdao = new Projectdao();
//		projdao.saveProject(proj1);
//		projdao.saveProject(proj2);
//		projdao.saveProject(proj3);
		
		Employeesdao empdao = new Employeesdao();
//		empdao.saveEmployee(emp1);
//		empdao.saveEmployee(emp2);
//		empdao.saveEmployee(emp3);
		
//		Get the data
//		projdao.getProject(1);
	    empdao.getEmployee(837198);

//		Delete
      	empdao.deleteEmployee(837198);
		
//		update
      	Project proj = new Project();

		proj.setClient("All State ");
		proj.setWbs_code("	Al-95003.009.01");
		proj.setManager_name("Ravi Shahshtri");
		proj.setTech("Java");
		projdao.updateProject(3, proj);
		
		
	}
}
