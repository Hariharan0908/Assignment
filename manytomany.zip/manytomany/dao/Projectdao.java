package manytomany.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import manytomany.dto.Project;
public class Projectdao 
{
	public EntityManager getEntityManager() {
		return Persistence.createEntityManagerFactory("vinod").createEntityManager();
	}
	
	public void saveProject(Project proj) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(proj);
		entityTransaction.commit();
	}
	public void getProject(int id) {
		EntityManager entityManager=getEntityManager();
		Project proj=entityManager.find(Project.class, id);
		if(proj !=null) {
			System.out.println(proj);
		}else {
			System.out.println("id is not present");
		}
	}
	

	public void deleteProject(int id) {
		EntityManager entityManager=getEntityManager();
		Project proj=entityManager.find(Project.class, id);
		if(proj !=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(proj);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}
	
	public void updateProject(int id,Project proj) {
		EntityManager entityManager=getEntityManager();
		Project dbproj=entityManager.find(Project.class, id);
		if(dbproj !=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			proj.setId(id);
			entityManager.merge(proj);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}
}
