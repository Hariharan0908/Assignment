package manytomany.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.swing.border.EtchedBorder;

import manytomany.dto.Employees;
public class Employeesdao 
{	
	public EntityManager getEntityManager() 
	{
		return Persistence.createEntityManagerFactory("vinod").createEntityManager();
	}
	
	public void saveEmployee(Employees emp) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(emp);
		entityTransaction.commit();
	}
	
	public void getEmployee(int id) {
		EntityManager entityManager=getEntityManager();
		Employees emp=entityManager.find(Employees.class, id);
		if(emp!=null) {
			System.out.println(emp);
		}else {
			System.out.println("id is not present");
		}
	}
	
	public void deleteEmployee(int id) {
		EntityManager entityManager=getEntityManager();
		Employees emp=entityManager.find(Employees.class, id);
		if(emp!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(emp);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}
	
	public void updateEmployee(int id,Employees emp) {
		EntityManager entityManager=getEntityManager();
		Employees dbemp=entityManager.find(Employees.class, id);
		if(dbemp!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			emp.setId(id);
			emp.setProj(dbemp.getProj());
			entityManager.merge(emp);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}

}
