package manytomany.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Project 
{
	@Id
	private int id;
	private String Client;
	private String Wbs_code;
	private String Manager_name;
	private String Tech;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClient() {
		return Client;
	}
	public void setClient(String client) {
		Client = client;
	}
	public String getWbs_code() {
		return Wbs_code;
	}
	public void setWbs_code(String wbs_code) {
		Wbs_code = wbs_code;
	}
	public String getManager_name() {
		return Manager_name;
	}
	public void setManager_name(String manager_name) {
		Manager_name = manager_name;
	}
	public String getTech() {
		return Tech;
	}
	public void setTech(String tech) {
		Tech = tech;
	}
	@Override
	public String toString() {
		return "Project [id=" + id + ", Client=" + Client + ", Wbs_code=" + Wbs_code + ", Manager_name=" + Manager_name
				+ ", Tech=" + Tech + "]";
	}
	
	
}
