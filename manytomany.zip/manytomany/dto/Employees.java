package manytomany.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Employees {
	@Id
	private int id;
	private String name;
	private String role;
	private int GCM;
	
	@ManyToMany
	List<Project> proj = new ArrayList<Project>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getGCM() {
		return GCM;
	}

	public void setGCM(int gCM) {
		GCM = gCM;
	}

	public List<Project> getProj() {
		return proj;
	}

	public void setProj(List<Project> proj) {
		this.proj = proj;
	}

	@Override
	public String toString() {
		return "Employees [id=" + id + ", name=" + name + ", role=" + role + ", GCM=" + GCM + ", proj=" + proj + "]";
	}

	
	
}
