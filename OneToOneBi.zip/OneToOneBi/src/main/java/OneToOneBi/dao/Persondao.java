package OneToOneBi.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import OneToOneBi.dto.Person;



public class Persondao 
{
	public void savePerson(Person person)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(person);
		et.commit();
	}
	public void getPerson(int id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		Person person = em.find(Person.class,id);
		if(person != null)
		{
			System.out.println(person);
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void deletePerson(int id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Person person = em.find(Person.class,id);
		if(person != null)
		{
			et.begin();
			em.remove(person);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void updatePerson(int id, Person person)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Person dbperson = em.find(Person.class,id);
		if(dbperson != null)
		{
			et.begin();
			person.setId(id);
			em.merge(person);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}		
	}
}
