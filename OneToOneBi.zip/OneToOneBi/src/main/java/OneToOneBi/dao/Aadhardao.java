package OneToOneBi.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import OneToOneBi.dto.Aadhar;



public class Aadhardao 
{
	public void saveAadhar(Aadhar aadhar)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(aadhar);
		et.commit();
	}
	public void getAadhar(int id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		Aadhar aadhar = em.find(Aadhar.class,id);
		if(aadhar != null)
		{
			System.out.println(aadhar);
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void deleteAadhar(int id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Aadhar aadhar = em.find(Aadhar.class,id);
		if(aadhar != null)
		{
			et.begin();
			em.remove(aadhar);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void updateAadhar(int id, Aadhar aadhar)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Aadhar dbaadhar = em.find(Aadhar.class,id);
		if(dbaadhar != null)
		{
			et.begin();
			aadhar.setId(id);
//			cust.setTransac(dbcust.getTransac());
			em.merge(aadhar);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
		
	}
}
