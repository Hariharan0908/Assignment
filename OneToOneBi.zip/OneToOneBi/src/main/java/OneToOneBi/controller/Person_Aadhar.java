package OneToOneBi.controller;

import OneToOneBi.dao.Aadhardao;
import OneToOneBi.dao.Persondao;
import OneToOneBi.dto.Aadhar;
import OneToOneBi.dto.Person;

public class Person_Aadhar 
{
	public static void main(String[] args) 
	{
		Person person = new Person();
		person.setId(3);
		person.setName("Sakthi");
		person.setAddress("Bandra");
		Aadhar aadhar = new Aadhar();
		aadhar.setId(300);
		aadhar.setName("Sakthivel S");
		aadhar.setAge(23);
		aadhar.setPerson(person);
		person.setAadhar(aadhar);
		
		
		Persondao persondao = new Persondao();
//		persondao.savePerson(person);
		
//		persondao.updatePerson(3, person);
//		persondao.getPerson(3);
		
		persondao.deletePerson(3);
	}
}
