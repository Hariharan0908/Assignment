package OneToOne.controller;

import OneToOne.dao.Customerdao;
import OneToOne.dao.Transactiondao;
import OneToOne.dto.Customer;
import OneToOne.dto.Transaction;

public class Customer_Transaction 
{
	public static void main(String[] args) 
	{
//		Transaction tra1 = new Transaction();
//		tra1.setId(546987);
//		tra1.setDate("2023-09-11");
//		tra1.setTotal(15000);
//		
//		Transaction tra2 = new Transaction();
//		tra2.setId(36457874);
//		tra2.setDate("2023-09-12");
//		tra2.setTotal(18784);
//		
//		Transaction tra3 = new Transaction();
//		tra3.setId(98782883);
//		tra3.setDate("2023-08-11");
//		tra3.setTotal(20000);
//		
//		Customer cust1 = new Customer();
//		cust1.setId(4546);
//		cust1.setName("Hariharan");
//		cust1.setEmail("hariharanmani24@gmail.com");
//		cust1.setAddress("Chennai");
//		cust1.setTransac(tra1);
//		
//		Customer cust2 = new Customer();
//		cust2.setId(78374);
//		cust2.setName("VIkram Rathore");
//		cust2.setEmail("vikramrath@gmail.com");
//		cust2.setAddress("Mumbai");
//		cust2.setTransac(tra2);
//		
//		Customer cust3 = new Customer();
//		cust3.setId(8735);
//		cust3.setName("Azad");
//		cust3.setEmail("azad@gmail.com");
//		cust3.setAddress("Marathalli");
//		cust3.setTransac(tra3);
		
		Customerdao custdao = new Customerdao();
		Transactiondao transdao = new Transactiondao();
		
//		transdao.saveTransaction(tra1);
//		transdao.saveTransaction(tra2);
//		transdao.saveTransaction(tra3);
//		
//		custdao.saveCustomer(cust1);
//		custdao.saveCustomer(cust2);
//		custdao.saveCustomer(cust3);
		
//		Customer cus = new Customer();
//		cus.setName("Vikram Rathore R");
//		cus.setAddress("Mumbai");
//		cus.setEmail("vik-rat@gmail.com");
//		custdao.updateCustomer(8735, cus);
		
		custdao.getCustomer(78374);
		custdao.deleteCustomer(78374);
		
	}
}
