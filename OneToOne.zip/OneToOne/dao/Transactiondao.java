package OneToOne.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import OneToOne.dto.Transaction;

public class Transactiondao 
{
	public void saveTransaction(Transaction trans)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(trans);
		et.commit();
	}
	public void getTransaction(long id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		Transaction trans = em.find(Transaction.class,id);
		if(trans != null)
		{
			System.out.println(trans);
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void deleteTransaction(long id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Transaction trans = em.find(Transaction.class,id);
		if(trans != null)
		{
			et.begin();
			em.remove(trans);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void updateTransaction(long id,Transaction trans)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Transaction dbtrans = em.find(Transaction.class,id);
		if(dbtrans != null)
		{
			et.begin();
			trans.setId(id);
			em.merge(trans);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
		
	}
}
