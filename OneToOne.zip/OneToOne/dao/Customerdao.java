package OneToOne.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import OneToOne.dto.Customer;
import OneToOne.dto.Transaction;


public class Customerdao 
{
	public void saveCustomer(Customer cust)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(cust);
		et.commit();
	}
	public void getCustomer(long id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		Customer cust = em.find(Customer.class,id);
		if(cust != null)
		{
			System.out.println(cust);
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void deleteCustomer(long id)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Customer cust = em.find(Customer.class,id);
		if(cust != null)
		{
			et.begin();
			em.remove(cust);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
	}
	public void updateCustomer(long id,Customer cust)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("vinod");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Customer dbcust = em.find(Customer.class,id);
		if(dbcust != null)
		{
			et.begin();
			cust.setId(id);
			cust.setTransac(dbcust.getTransac());
			em.merge(cust);
			et.commit();
		}
		else
		{
			System.out.println("Sorry, Id is not present.");
		}
		
	}
}
