package manytoone.controller;

import manytoone.dao.Collegedao;
import manytoone.dao.Studentdao;
import manytoone.dto.College;
import manytoone.dto.Student;

public class Student_College 
{
	public static void main(String[] args) {
//		College clg1 = new College();
//		clg1.setId(1);
//		clg1.setName("Jeppiaar Maamallan Engineering College");
//		clg1.setClg_code(2110);
//		clg1.setAddress("Sriperumbudur");
//		
//		College clg2 = new College();
//		clg1.setId(2);
//		clg1.setName("Jeppiaar Engineering College");
//		clg1.setClg_code(1405);
//		clg1.setAddress("OMR - Shollinganallur");
//		
//		Student stu1 = new Student();
//		stu1.setId(1);
//		stu1.setName("Hariharan");
//		stu1.setDept("IT");
//		stu1.setYear(4);
//		stu1.setClg(clg1);
//		
//		Student stu2 = new Student();
//		stu2.setId(2);
//		stu2.setName("Balaji Kannan");
//		stu2.setDept("CSE");
//		stu2.setYear(4);
//		stu2.setClg(clg1);
//		
//		Student stu3 = new Student();
//		stu3.setId(3);
//		stu3.setName("Monisha");
//		stu3.setDept("IT");
//		stu3.setYear(2);
//		stu3.setClg(clg2);
		
		Collegedao clgdao = new Collegedao();
//		clgdao.saveCollege(clg1);
//		clgdao.saveCollege(clg2);
		
		Studentdao studao = new Studentdao();
//		studao.saveStudent(stu1);
//		studao.saveStudent(stu2);
//		studao.saveStudent(stu3);
//		
		// get
		
//		clgdao.getCollege(2);
//		studao.getStudent(3);
		
		
//		update
//		College clg = new College();
//		
//		clg.setName("Jeppiaar Maamallan Engineering College");
//		clg.setClg_code(2110);
//		clg.setAddress("Sriperumbudur");
//		clgdao.updateCompany(2, clg);
		
//		delete
		
		studao.deleteStudent(2);
	}
}
