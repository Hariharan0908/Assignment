package manytoone.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import manytoone.dto.Student;

public class Studentdao 
{
	public EntityManager getEntityManager() {
		return Persistence.createEntityManagerFactory("vinod").createEntityManager();
	}
	
	public void saveStudent(Student stu) 
	{
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(stu);
		entityTransaction.commit();
	}
	
	public void getStudent(int id) {
		EntityManager entityManager=getEntityManager();
		Student stu=entityManager.find(Student.class, id);
		if(stu!=null) {
			System.out.println(stu);
		}else {
			System.out.println("id is not present");
		}
	}
	public void deleteStudent(int id) {
		EntityManager entityManager=getEntityManager();
		Student stu=entityManager.find(Student.class, id);
		if(stu!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(stu);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}
	
	public void updateEmployee(int id,Student stu) {
		EntityManager entityManager=getEntityManager();
		Student dbstu=entityManager.find(Student.class, id);
		if(dbstu!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			stu.setId(id);
			stu.setClg(dbstu.getClg());
			entityManager.merge(stu);
			
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
		
		
	}
}
