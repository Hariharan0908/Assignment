package manytoone.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import manytoone.dto.College;
public class Collegedao 
{
	public EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vinod");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager;
	}
	
	public void saveCollege(College clg) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(clg);
		entityTransaction.commit();
	}
	public void getCollege(int id) {
		EntityManager entityManager=getEntityManager();
		College clg=entityManager.find(College.class, id);
		if(clg!=null) {
			System.out.println(clg);
		}else {
			System.out.println("id is not present");
		}
	}
	public void deleteCollege(int id) {
		EntityManager entityManager=getEntityManager();
		College clg=entityManager.find(College.class, id);
		if(clg!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(clg);
			entityTransaction.commit();
		}else {
			System.out.println("id is not present");
		}
	}
	
	public void updateCompany(int id,College clg) {
		EntityManager entityManager=getEntityManager();
		College dbclg=entityManager.find(College.class, id);
		if(dbclg!=null) {

			EntityTransaction entityTransaction =entityManager.getTransaction();
			entityTransaction.begin();
			clg.setId(id);
			 
			entityTransaction.commit();
		}else {
//			id is not present
			System.out.println("Sorry id is not present");
		}
		
		
	}
}
