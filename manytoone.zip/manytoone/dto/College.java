package manytoone.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class College 
{
	@Id
	private int id;
	private String name;
	private int clg_code;
	private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getClg_code() {
		return clg_code;
	}
	public void setClg_code(int clg_code) {
		this.clg_code = clg_code;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "College [id=" + id + ", name=" + name + ", clg_code=" + clg_code + ", address=" + address + "]";
	}
	
	
}
