package onetomany.controller;

import java.util.ArrayList;
import java.util.List;

import onetomany.dao.Buildingdao;
import onetomany.dao.Floordao;
import onetomany.dto.Building;
import onetomany.dto.Floor;

public class Building_floor 
{
	public static void main(String[] args) {
//		Building building = new Building();
//		building.setId(1);
//		building.setName("SDB2");
//		building.setCompany("Eviden");
//		
//		Floor floor1 = new Floor();
//		floor1.setFoor_no(1);
//		floor1.setWing("A");
//		floor1.setProject_name("FedEx");
//		
//		Floor floor2 = new Floor();
//		floor2.setFoor_no(2);
//		floor2.setWing("B");
//		floor2.setProject_name("Humana");
//		
//		Floor floor3 = new Floor();
//		floor3.setFoor_no(5);
//		floor3.setWing("A & B");
//		floor3.setProject_name("UPS");
//		
//		List<Floor> floors = new ArrayList<Floor>();
//		floors.add(floor1);
//		floors.add(floor2);
//		floors.add(floor3);
		
		Floordao floordao = new Floordao();
//		floordao.saveFloor(floors);
		
		Buildingdao builddao = new Buildingdao();
//		builddao.saveBuilding(building);
		
//		2. get the data
//		floordao.getFloor(5);
//		builddao.getBuilding(1);

//		3.update the data
//		Building building = new Building();
//		building.setName("SDB3");
//		building.setCompany("Atos");
//		builddao.updateBuilding(1, building);
		
//		4. delete
		floordao.deleteFloor(2);
		
	}
}
