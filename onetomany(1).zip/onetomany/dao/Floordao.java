package onetomany.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import onetomany.dto.Floor;
public class Floordao 
{
	public EntityManager getEntityManager() 
	{
		return Persistence.createEntityManagerFactory("vinod").createEntityManager();
	}
	

	public void saveFloor(Floor floor) 
	{
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(floor);
		entityTransaction.commit();
	}
	public void saveFloor(List<Floor> floors) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		for(Floor floor:floors) {
			entityManager.persist(floor);
		}
		entityTransaction.commit();
	}
	
	public void getFloor(int id) 
	{
		EntityManager entityManager=getEntityManager();
		Floor floor=entityManager.find(Floor.class, id);
		if(floor!=null) 
		{
			System.out.println(floor);
		}else {
			System.out.println("Sorry id is not present");
		}

	}
	
	
	public void deleteFloor(int id) {
		EntityManager entityManager=getEntityManager();
		Floor floor=entityManager.find(Floor.class, id);
		if(floor!=null){
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(floor);
			entityTransaction.commit();
		}else {
			System.out.println("Sorry id is not present");
		}
	}
	
}
