package onetomany.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import onetomany.dto.Building;


public class Buildingdao 
{
	public EntityManager getEntityManager() 
	{
		return Persistence.createEntityManagerFactory("vinod").createEntityManager();
	}
	

	public void saveBuilding(Building build) 
	{
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(build);
		entityTransaction.commit();
	}
	
	public void getBuilding(int id) 
	{
		EntityManager entityManager=getEntityManager();
		Building build=entityManager.find(Building.class, id);
		if(build!=null) 
		{
			System.out.println(build);
		}else {
			System.out.println("Sorry id is not present");
		}

	}
	
	
	public void deleteBuilding(int id) {
		EntityManager entityManager=getEntityManager();
		Building build=entityManager.find(Building.class, id);
		if(build!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.remove(build);
			entityTransaction.commit();
		}else {
			System.out.println("Sorry id is not present");
		}
	}
	public void updateBuilding(int id , Building building)
	{
		EntityManager entityManager=getEntityManager();
		Building dbbuild=entityManager.find(Building.class, id);
		if(dbbuild!=null) {
			EntityTransaction entityTransaction=entityManager.getTransaction();
			entityTransaction.begin();
			building.setId(id);
			building.setFloor(dbbuild.getFloor());
			entityManager.merge(building);
			entityTransaction.commit();
		}else {
			System.out.println("Sorry id is not present");
		}
	}
}
