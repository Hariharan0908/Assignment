package onetomany.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Floor 
{
	@Id
	private int foor_no;
	private String wing;
	private String Project_name;
	public int getFoor_no() {
		return foor_no;
	}
	public void setFoor_no(int foor_no) {
		this.foor_no = foor_no;
	}
	public String getWing() {
		return wing;
	}
	public void setWing(String wing) {
		this.wing = wing;
	}
	public String getProject_name() {
		return Project_name;
	}
	public void setProject_name(String project_name) {
		Project_name = project_name;
	}
	@Override
	public String toString() {
		return "Floor [foor_no=" + foor_no + ", wing=" + wing + ", Project_name=" + Project_name + "]";
	}
	
}
