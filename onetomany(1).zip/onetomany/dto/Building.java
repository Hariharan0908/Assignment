package onetomany.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Building 
{
	@Id
	private int id;
	private String name;
	private String Company;
	
	@OneToMany
	List<Floor> floor = new ArrayList<Floor>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public List<Floor> getFloor() {
		return floor;
	}

	public void setFloor(List<Floor> floor) {
		this.floor = floor;
	}

	@Override
	public String toString() {
		return "Building [id=" + id + ", name=" + name + ", Company=" + Company + ", floor=" + floor + "]";
	}

	
	
	
}
